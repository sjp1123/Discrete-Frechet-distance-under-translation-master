| family | inst | arm | LMF fail | LMF max abs err | LMF hang/crash | decider queries | wrong NO (δ ≥ δ* + resolution) | wrong YES (δ < δ*−band) | tie/below-resolution: NO/YES | either (YES/NO) | dec hang/crash |
|---|--:|---|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| review | 3 | original | 0 | 7.68e-09 | 0 | 42 | 0 | 0 | 2/1 | 0/3 | 0 |
| review | 3 | candidate7 | 0 | 2.77e-09 | 0 | 42 | 0 | 0 | 2/1 | 0/3 | 0 |
| far_t_1e7 | 800 | original | 0 | 9.59e-09 | 0 | 11,140 | 0 | 0 | 403/2047 | 553/237 | 0 |
| far_t_1e7 | 800 | candidate7 | 0 | 4.93e-09 | 0 | 11,140 | 0 | 0 | 755/1695 | 306/484 | 0 |
| far_t_1e8 | 800 | original | 26 | 1.64e+00 | 0 | 11,110 | 10 | 0 | 450/2025 | 543/1027 | 0 |
| far_t_1e8 | 800 | candidate7 | 0 | 9.19e-09 | 0 | 11,110 | 0 | 0 | 797/1678 | 312/1258 | 0 |
| far_t_sig | 800 | original | 0 | 8.75e-09 | 0 | 11,098 | 0 | 0 | 139/2346 | 443/340 | 0 |
| far_t_sig | 800 | candidate7 | 0 | 4.72e-09 | 0 | 11,098 | 0 | 0 | 121/2364 | 14/769 | 0 |
| **total** | 2,403 | original | 26 | | 0 | 33,390 | 10 | 0 | 994/6419 | | 0 |
| **total** | 2,403 | candidate7 | 0 | | 0 | 33,390 | 0 | 0 | 1675/5738 | | 0 |
