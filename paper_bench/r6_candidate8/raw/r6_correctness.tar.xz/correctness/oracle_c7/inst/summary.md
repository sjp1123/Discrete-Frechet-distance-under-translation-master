| family | inst | arm | LMF fail | LMF max abs err | LMF hang/crash | decider queries | wrong NO (δ ≥ δ* + resolution) | wrong YES (δ < δ*−band) | tie/below-resolution: NO/YES | either (YES/NO) | dec hang/crash |
|---|--:|---|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| uniform | 1,500 | candidate7 | 0 | 1.06e-08 | 0 | 20,886 | 0 | 0 | 187/1408 | 97/1384 | 0 |
| grid | 1,500 | candidate7 | 0 | 1.55e-08 | 0 | 20,790 | 0 | 0 | 291/1384 | 24/1441 | 0 |
| cluster | 1,200 | candidate7 | 0 | 2.28e-08 | 0 | 16,477 | 0 | 0 | 53/1209 | 939/1458 | 7 |
| collinear | 1,200 | candidate7 | 0 | 1.10e-08 | 0 | 16,704 | 0 | 0 | 242/1038 | 116/1068 | 0 |
| copy | 1,200 | candidate7 | 0 | 2.20e-08 | 0 | 14,375 | 0 | 0 | 2746/1554 | 1237/3261 | 0 |
| singleton | 600 | candidate7 | 0 | 4.83e-09 | 0 | 7,908 | 0 | 0 | 510/500 | 34/484 | 0 |
| revisit | 1,000 | candidate7 | 0 | 1.35e-08 | 0 | 13,880 | 0 | 0 | 149/951 | 161/819 | 0 |
| offset_sig | 1,200 | candidate7 | 0 | 1.07e-08 | 0 | 16,686 | 0 | 0 | 118/3577 | 31/1150 | 0 |
| big | 1,000 | candidate7 | 0 | 4.95e-09 | 0 | 13,940 | 0 | 0 | 145/915 | 81/909 | 0 |
| tiny | 1,000 | candidate7 | 0 | 4.84e-09 | 0 | 13,904 | 0 | 0 | 153/927 | 84/1886 | 0 |
| real_chars | 1,500 | candidate7 | 0 | 4.95e-09 | 0 | 20,994 | 0 | 0 | 173/1332 | 201/1298 | 0 |
| real_sig | 1,500 | candidate7 | 0 | 5.04e-09 | 0 | 21,000 | 0 | 0 | 9/4449 | 127/1373 | 0 |
| medium_uniform | 250 | candidate7 | 0 | 4.43e-09 | 0 | 3,500 | 0 | 0 | 10/240 | 7/243 | 0 |
| medium_real_chars | 250 | candidate7 | 0 | 4.61e-09 | 0 | 3,500 | 0 | 0 | 24/226 | 44/206 | 0 |
| medium_real_sig | 250 | candidate7 | 0 | 4.53e-09 | 0 | 3,500 | 0 | 0 | 0/732 | 35/215 | 0 |
| **total** | 15,150 | candidate7 | 0 | | 0 | 208,044 | 0 | 0 | 4810/20442 | | 7 |
