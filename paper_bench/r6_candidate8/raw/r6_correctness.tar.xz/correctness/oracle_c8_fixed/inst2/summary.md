| family | inst | arm | LMF fail | LMF max abs err | LMF hang/crash | decider queries | wrong NO (δ ≥ δ* + resolution) | wrong YES (δ < δ*−band) | tie/below-resolution: NO/YES | either (YES/NO) | dec hang/crash |
|---|--:|---|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| review | 3 | candidate8 | 0 | 8.34e-09 | 0 | 42 | 0 | 0 | 2/1 | 1/2 | 0 |
| far_t_1e7 | 800 | candidate8 | 0 | 9.87e-09 | 0 | 11,140 | 0 | 0 | 206/2244 | 712/78 | 0 |
| far_t_1e8 | 800 | candidate8 | 0 | 9.19e-09 | 0 | 11,110 | 0 | 0 | 760/1715 | 323/1247 | 0 |
| far_t_sig | 800 | candidate8 | 0 | 9.63e-09 | 0 | 11,098 | 0 | 0 | 121/2364 | 665/118 | 0 |
| **total** | 2,403 | candidate8 | 0 | | 0 | 33,390 | 0 | 0 | 1089/6324 | | 0 |
