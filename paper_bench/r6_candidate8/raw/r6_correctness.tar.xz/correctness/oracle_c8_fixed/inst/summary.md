| family | inst | arm | LMF fail | LMF max abs err | LMF hang/crash | decider queries | wrong NO (δ ≥ δ* + resolution) | wrong YES (δ < δ*−band) | tie/below-resolution: NO/YES | either (YES/NO) | dec hang/crash |
|---|--:|---|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| uniform | 1,500 | candidate8 | 0 | 1.28e-08 | 0 | 20,886 | 0 | 0 | 140/1455 | 1265/216 | 0 |
| grid | 1,500 | candidate8 | 0 | 1.55e-08 | 0 | 20,790 | 0 | 0 | 291/1384 | 1010/455 | 0 |
| cluster | 1,200 | candidate8 | 0 | 2.28e-08 | 0 | 16,477 | 0 | 0 | 13/1249 | 1799/598 | 7 |
| collinear | 1,200 | candidate8 | 0 | 1.29e-08 | 0 | 16,704 | 0 | 0 | 191/1089 | 820/364 | 0 |
| copy | 1,200 | candidate8 | 0 | 2.20e-08 | 0 | 14,375 | 0 | 0 | 2641/1659 | 1815/2683 | 0 |
| singleton | 600 | candidate8 | 0 | 1.26e-08 | 0 | 7,908 | 0 | 0 | 492/518 | 451/67 | 0 |
| revisit | 1,000 | candidate8 | 0 | 1.35e-08 | 0 | 13,880 | 0 | 0 | 136/964 | 689/291 | 0 |
| offset_sig | 1,200 | candidate8 | 0 | 9.78e-09 | 0 | 16,686 | 0 | 0 | 118/3577 | 1007/174 | 0 |
| big | 1,000 | candidate8 | 0 | 1.27e-08 | 0 | 13,940 | 0 | 0 | 87/973 | 855/135 | 0 |
| tiny | 1,000 | candidate8 | 0 | 1.29e-08 | 0 | 13,904 | 0 | 0 | 104/976 | 1665/305 | 0 |
| real_chars | 1,500 | candidate8 | 0 | 1.29e-08 | 0 | 20,994 | 0 | 0 | 62/1443 | 1068/431 | 0 |
| real_sig | 1,500 | candidate8 | 0 | 9.82e-09 | 0 | 21,000 | 0 | 0 | 9/4449 | 603/897 | 0 |
| medium_uniform | 250 | candidate8 | 0 | 1.30e-08 | 0 | 3,500 | 0 | 0 | 0/250 | 231/19 | 0 |
| medium_real_chars | 250 | candidate8 | 0 | 1.27e-08 | 0 | 3,500 | 0 | 0 | 8/242 | 195/55 | 0 |
| medium_real_sig | 250 | candidate8 | 0 | 8.88e-09 | 0 | 3,500 | 0 | 0 | 0/732 | 108/142 | 0 |
| **total** | 15,150 | candidate8 | 0 | | 0 | 208,044 | 0 | 0 | 4292/20960 | | 7 |
