| family | inst | arm | LMF fail | LMF max abs err | LMF hang/crash | decider queries | wrong NO (δ ≥ δ* + resolution) | wrong YES (δ < δ*−band) | tie/below-resolution: NO/YES | either (YES/NO) | dec hang/crash |
|---|--:|---|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| review | 3 | candidate7 | 0 | 2.77e-09 | 0 | 42 | 0 | 0 | 2/1 | 0/3 | 0 |
| review | 3 | candidate8 | 0 | 8.34e-09 | 0 | 42 | 0 | 0 | 2/1 | 1/2 | 0 |
| far_t_1e7 | 800 | candidate7 | 0 | 4.93e-09 | 0 | 11,140 | 0 | 0 | 755/1695 | 306/484 | 0 |
| far_t_1e7 | 800 | candidate8 | 0 | 1.30e-08 | 0 | 11,140 | 0 | 0 | 206/2244 | 712/78 | 0 |
| far_t_1e8 | 800 | candidate7 | 0 | 9.19e-09 | 0 | 11,110 | 0 | 0 | 797/1678 | 312/1258 | 0 |
| far_t_1e8 | 800 | candidate8 | 2 | 1.94e-02 | 0 | 11,110 | 0 | 0 | 321/2154 | 663/907 | 0 |
| far_t_sig | 800 | candidate7 | 0 | 4.72e-09 | 0 | 11,098 | 0 | 0 | 121/2364 | 14/769 | 0 |
| far_t_sig | 800 | candidate8 | 0 | 9.71e-09 | 0 | 11,098 | 0 | 0 | 121/2364 | 665/118 | 0 |
| **total** | 2,403 | candidate7 | 0 | | 0 | 33,390 | 0 | 0 | 1675/5738 | | 0 |
| **total** | 2,403 | candidate8 | 2 | | 0 | 33,390 | 0 | 0 | 650/6763 | | 0 |
