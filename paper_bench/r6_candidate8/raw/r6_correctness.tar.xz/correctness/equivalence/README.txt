candidate8 e264dd4 (measured in r6 run 1) vs candidate8 f51bcbd (centre-rounding fix), deterministic outputs
- Characters LMF 21,000 pairs: value and bbcalls identical on 21,000
- Sigspatial LMF 1,000 pairs: identical on 998; 2 differ:
    pair 690 file-019455.dat/file-019209.dat  value +3.58e-09, calls 418 -> 422
    pair 763 file-016399.dat/file-003209.dat  value +3.32e-09, calls 2846 -> 2851
- Decider 4^l, 69 files x 1,000 queries: answer and bbcalls identical on 69,000
- bad2_<MAXREGION_SLACK>.csv: far_t_1e8 pairs 00005 and 00092 on e264dd4 (oracle 10.607474521422834,
  9.0198914363192966): wrong for budget, caller, 4e-9, 2e-9, 1e-9; right for 0.
- Ch300/Sig40 subsets: candidate8 with MAXREGION_SLACK=0 identical to candidate7 (value, bbcalls), before and after the fix.
